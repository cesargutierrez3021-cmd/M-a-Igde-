# NOAH Conductor v1.0.38 — corrección GPS

Se corrigió el cálculo de kilómetros de la burbuja y del rastreador web.

## Cambios

La burbuja ya no mezcla GPS con ubicación de red. Para acumular kilómetros utiliza únicamente `GPS_PROVIDER`. Se descartan fijaciones con precisión inválida o superior a 35 metros, saltos separados por más de 30 segundos y desplazamientos que implican una velocidad superior a 55 m/s aproximadamente 198 km/h. Las posiciones rechazadas reinician la referencia para que el salto no se sume posteriormente.

El rastreador web recibió los mismos límites de intervalo y velocidad máxima para que el comportamiento sea consistente si se inicia desde la aplicación.

## Validación

Oxlint: 0 warnings y 0 errors.

Android lint y assembleDebug: BUILD SUCCESSFUL.

APK: versión 1.0.38, código 38.

SHA-256: `f9bae172946e4e0c7f7c90877a901b3c013b09febe9997f0a51a59b4a3692212`.
