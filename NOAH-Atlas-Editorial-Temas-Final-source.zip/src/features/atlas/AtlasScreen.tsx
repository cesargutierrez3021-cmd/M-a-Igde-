import { useEffect, useMemo, useState } from 'react'
import { Activity, AlarmClock, ArrowDownLeft, ArrowUpRight, CircleDollarSign, CloudSun, Droplets, Gauge, Home, Landmark, ListChecks, MapPin, Moon, Play, Route, ShieldAlert, Sparkles, Timer, Wallet, Waves, Zap } from 'lucide-react'
import { Link } from 'react-router-dom'
import { Pantalla } from '../../components/shell/Pantalla'
import { useTienda } from '../../lib/store'
import { useViaje } from '../trabajo/useViaje'
import { calcularResumen, duracionViajeMs } from '../../lib/selectors'
import { formatearDuracion, formatearKm, formatearMiles, formatearPesosCompacto } from '../../lib/format'
import { useAtlasTheme } from './atlasTheme'

type Theme = 'marea' | 'taller' | 'pulso'
const themes: { id: Theme; name: string; hint: string }[] = [
  { id: 'marea', name: 'Marea', hint: 'mapa suave y respirado' },
  { id: 'taller', name: 'Taller', hint: 'fichas de control' },
  { id: 'pulso', name: 'Pulso', hint: 'lectura intensa y modular' },
]

function today(iso: string) { return new Date(iso).toDateString() === new Date().toDateString() }

export function AtlasScreen() {
  const estado = useTienda()
  const viaje = useViaje()
  const { theme, setTheme, color } = useAtlasTheme()
  const [now, setNow] = useState(Date.now)
  const jornada = estado.jornadaAbierta()
  const resumen = useMemo(() => calcularResumen(estado, 'hoy'), [estado])
  const viajes = estado.viajes.filter((v) => today(v.inicioISO))
  const totalJourney = jornada ? now - new Date(jornada.inicioISO).getTime() : 0
  const realTime = viajes.reduce((sum, v) => sum + duracionViajeMs(v, now), 0) + (viaje.activo ? viaje.msTranscurridos : 0)
  const deadTime = Math.max(0, totalJourney - realTime)
  const paidTime = viajes.filter((v) => (v.pago ?? 0) > 0).reduce((sum, v) => sum + duracionViajeMs(v, now), 0) + (viaje.activo && resumen.ingresoViajes > 0 ? viaje.msTranscurridos : 0)
  const paidIncome = viajes.reduce((sum, v) => sum + (v.pago ?? 0), 0)
  const hourly = paidTime > 0 ? paidIncome / (paidTime / 3600000) : 0
  const deadValue = deadTime / 3600000 * hourly
  const gasoline = resumen.gastosMoto.filter((g) => g.tipo === 'Gasolina').reduce((sum, g) => sum + g.valor, 0)
  const house = estado.gastosHogar.filter((g) => !g.pagado).reduce((sum, g) => sum + g.valor, 0)
  const debt = estado.deudas.filter((d) => !d.archivada).reduce((sum, d) => sum + Math.max(0, d.saldoTotal - d.abonado), 0)
  const nextSignal = estado.recordatorios.find((r) => !r.disparado)
  const nextRoutine = estado.rutina[0]

  useEffect(() => { const id = window.setInterval(() => setNow(Date.now()), 1000); return () => window.clearInterval(id) }, [])

  const setJourney = () => { if (jornada) { if (viaje.activo) viaje.terminarViaje(true); estado.terminarJornada() } else estado.iniciarJornada() }
  const metrics = [
    { icon: Timer, label: 'Tiempo de jornada', value: formatearDuracion(totalJourney), tone: 'lime' },
    { icon: Route, label: 'Tiempo real trabajado', value: formatearDuracion(realTime), tone: 'cyan' },
    { icon: Moon, label: 'Tiempo muerto', value: formatearDuracion(deadTime), tone: 'orange' },
    { icon: CircleDollarSign, label: 'Dinero / hora real', value: hourly ? formatearMiles(hourly) : '—', tone: 'violet' },
    { icon: Droplets, label: 'Gasolina / km', value: resumen.km ? formatearPesosCompacto(gasoline / resumen.km) : '—', tone: 'blue' },
    { icon: ArrowDownLeft, label: 'Dinero que se va en espera', value: deadValue ? formatearPesosCompacto(deadValue) : '—', tone: 'red' },
  ]

  return <Pantalla>
    <div className={`atlas atlas-${theme} atlas-color-${color}`}>
      <header className="atlas-header"><div><span className="atlas-kicker">NOAH / ATLAS PERSONAL</span><h1>{theme === 'marea' ? 'Tu día, visto completo.' : theme === 'taller' ? 'Control de operación.' : 'El pulso de tu dinero.'}</h1><p>{jornada ? 'Jornada abierta · cada minuto tiene contexto.' : 'Abre la jornada para empezar a medir.'}</p></div><div className="atlas-date"><CloudSun size={18} /><span>{new Date(now).toLocaleDateString('es-CO', { weekday: 'short', day: 'numeric', month: 'short' })}</span></div></header>

      <section className="atlas-theme-switch"><span>FORMA DE VER</span><div>{themes.map((item) => <button key={item.id} className={theme === item.id ? 'selected' : ''} onClick={() => setTheme(item.id)}>{item.name}<small>{item.hint}</small></button>)}</div></section>

      {theme === 'marea' && <section className="marea-hero"><div className="marea-water"><span>NETO DE HOY</span><strong>{formatearPesosCompacto(resumen.neto)}</strong><small>{formatearKm(resumen.km)} de recorrido</small></div><div className="marea-wave"><Waves size={40} /><span>{viaje.activo ? 'EN RECORRIDO' : jornada ? 'EN ESPERA' : 'PAUSADO'}</span></div></section>}
      {theme === 'taller' && <section className="taller-hero"><div><span>HOJA DE TURNO</span><strong>{formatearPesosCompacto(resumen.neto)}</strong></div><div className="taller-stamp"><ShieldAlert size={19} /><span>{viaje.activo ? 'MOTOR ACTIVO' : 'MOTOR LISTO'}</span></div></section>}
      {theme === 'pulso' && <section className="pulso-hero"><div className="pulse-ring"><Activity size={32} /><strong>{formatearPesosCompacto(resumen.neto)}</strong><small>NETO / HOY</small></div><div><span>ESTADO DEL SISTEMA</span><strong>{viaje.activo ? 'VIAJE' : jornada ? 'JORNADA' : 'PAUSA'}</strong><small>{formatearKm(resumen.km)} · {viajes.length} viajes</small></div></section>}

      <section className="atlas-command"><button className="atlas-start" onClick={() => viaje.activo ? viaje.terminarViaje(true) : viaje.iniciarViaje()} disabled={!jornada}><span>{viaje.activo ? <Zap size={21} /> : <Play size={21} fill="currentColor" />}</span>{viaje.activo ? 'Finalizar viaje' : 'Iniciar viaje'}<ArrowUpRight size={18} /></button><button className="atlas-shift" onClick={setJourney}>{jornada ? 'Cerrar jornada' : 'Iniciar jornada'}</button></section>

      <section className="atlas-metrics"><div className="atlas-section-title"><span>LECTURA DEL DÍA</span><small>6 señales</small></div><div className="metric-grid">{metrics.map(({ icon: Icon, label, value, tone }) => <div key={label} className={`atlas-metric tone-${tone}`}><Icon size={17} /><span>{label}</span><strong>{value}</strong></div>)}</div></section>

      <section className="atlas-life"><div className="atlas-section-title"><span>VIDA ALREDEDOR DEL TURNO</span><small>lo que también importa</small></div><div className="life-grid"><Link to="/finanzas" className="life-card debt"><Landmark size={20} /><span>Deudas</span><strong>{formatearPesosCompacto(debt)}</strong><small>saldo pendiente</small></Link><Link to="/finanzas" className="life-card home"><Home size={20} /><span>Hogar</span><strong>{formatearPesosCompacto(house)}</strong><small>gastos sin pagar</small></Link><Link to="/avisos" className="life-card signal"><AlarmClock size={20} /><span>Señal</span><strong>{nextSignal ? 'Pendiente' : 'Limpio'}</strong><small>{nextSignal?.titulo || 'sin alertas próximas'}</small></Link><Link to="/rutina" className="life-card routine"><ListChecks size={20} /><span>Rutina</span><strong>{nextRoutine ? 'Programada' : 'Vacía'}</strong><small>{nextRoutine?.titulo || 'crea tu ritual'}</small></Link></div></section>

      <section className="atlas-quick"><span>ATAJOS DE OPERACIÓN</span><div><Link to="/finanzas"><Wallet size={17} /> Caja</Link><Link to="/balance"><Gauge size={17} /> Rendimiento</Link><Link to="/avisos"><AlarmClock size={17} /> Señales</Link><Link to="/rutina"><Sparkles size={17} /> Ritual</Link></div></section>
      <div className="atlas-footer"><MapPin size={13} /> {estado.ajustes.appPreferida} · {viaje.errorGps || 'GPS preparado'}</div>
    </div>
  </Pantalla>
}
