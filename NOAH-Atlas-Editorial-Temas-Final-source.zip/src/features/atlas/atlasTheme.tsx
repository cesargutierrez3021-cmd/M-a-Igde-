import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'

export type AtlasTheme = 'marea' | 'taller' | 'pulso'
export type AtlasColor = 'a' | 'b' | 'c'
export const ATLAS_THEMES: { id: AtlasTheme; name: string; hint: string }[] = [
  { id: 'marea', name: 'Marea', hint: 'flujo abierto' },
  { id: 'taller', name: 'Taller', hint: 'control técnico' },
  { id: 'pulso', name: 'Pulso', hint: 'modo intenso' },
]

const Contexto = createContext<{ theme: AtlasTheme; setTheme: (theme: AtlasTheme) => void; color: AtlasColor; setColor: (color: AtlasColor) => void }>({ theme: 'marea', setTheme: () => {}, color: 'a', setColor: () => {} })

export function AtlasThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<AtlasTheme>(() => {
    const saved = localStorage.getItem('noah-atlas-theme')
    return saved === 'taller' || saved === 'pulso' ? saved : 'marea'
  })
  const [color, setColor] = useState<AtlasColor>(() => {
    const saved = localStorage.getItem('noah-atlas-color')
    return saved === 'b' || saved === 'c' ? saved : 'a'
  })
  useEffect(() => { localStorage.setItem('noah-atlas-theme', theme) }, [theme])
  useEffect(() => { localStorage.setItem('noah-atlas-color', color) }, [color])
  useEffect(() => { document.documentElement.setAttribute('data-atlas-color', color) }, [color])
  return <Contexto.Provider value={{ theme, setTheme, color, setColor }}>{children}</Contexto.Provider>
}

export function useAtlasTheme() { return useContext(Contexto) }

export function AtlasThemePicker() {
  const { theme, setTheme, color, setColor } = useAtlasTheme()
  return <div className="atlas-global-theme"><span>APARIENCIA DE TODA LA APP</span><div>{ATLAS_THEMES.map((item) => <button key={item.id} className={theme === item.id ? 'selected' : ''} onClick={() => setTheme(item.id)}>{item.name}<small>{item.hint}</small></button>)}</div><div className="atlas-color-picker"><small>COLOR DE {theme.toUpperCase()}</small>{(['a', 'b', 'c'] as AtlasColor[]).map((item) => <button key={item} aria-label={`Color ${item}`} className={`color-${item} ${color === item ? 'selected' : ''}`} onClick={() => setColor(item)} />)}</div></div>
}

export function AtlasModuleFrame({ module, children }: { module: string; children: ReactNode }) {
  const { theme, color } = useAtlasTheme()
  const slug = module.toLowerCase().replaceAll(' ', '-')
  return <div className={`atlas atlas-${theme} atlas-color-${color} atlas-module-frame atlas-module-${slug}`}><div className="atlas-module-banner"><div><span className="atlas-kicker">ATLAS / ESTACIÓN</span><h1>{module}</h1><p>Este espacio también cambia con el modo visual elegido.</p></div><span className="atlas-module-code">{theme.toUpperCase()}</span></div><AtlasThemePicker />{children}</div>
}
