import { useAtlasTheme, ATLAS_THEMES, AtlasThemePicker } from '../atlas/atlasTheme'
import { useApariencia } from '../../lib/useApariencia'
import { Boton } from '../../components/ui/primitives'

export function EleccionApariencia() {
  const { confirmarEleccion, fijarTema } = useApariencia()
  const { theme, setTheme } = useAtlasTheme()
  return <div className="atlas-onboarding"><div className="onboarding-editorial"><span className="atlas-kicker">NOAH / EDITORIAL</span><h1>Una app, tres formas de trabajar.</h1><p>Editorial es la envolvente. Dentro puedes elegir cómo quieres leer y operar tu jornada.</p><div className="editorial-rule" /></div><div className="onboarding-themes">{ATLAS_THEMES.map((item) => <button key={item.id} className={theme === item.id ? 'selected' : ''} onClick={() => setTheme(item.id)}><span className={`onboarding-glyph glyph-${item.id}`}>{item.id === 'marea' ? '≈' : item.id === 'taller' ? '▣' : '◉'}</span><span><strong>{item.name}</strong><small>{item.hint}</small></span></button>)}</div><AtlasThemePicker /><Boton className="onboarding-continue" onClick={() => { fijarTema('editorial'); confirmarEleccion() }}>Entrar a Editorial</Boton></div>
}
