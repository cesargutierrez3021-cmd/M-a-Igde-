@file:Suppress("UseKtx", "SetTextI18n", "ObsoleteSdkInt", "ClickableViewAccessibility")

package com.noah.conductor.atlas.burbuja

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.animation.ValueAnimator
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.noah.conductor.atlas.MainActivity
import com.noah.conductor.atlas.R
import java.util.Locale
import kotlin.math.abs

class BurbujaService : Service(), TextToSpeech.OnInitListener {
    companion object {
        @Volatile var activo: Boolean = false
        const val ACCION_MOSTRAR = "mostrar"
        const val ACCION_ACTUALIZAR = "actualizar"
        const val EXTRA_KM = "km"
        const val EXTRA_TIEMPO = "tiempo"
        const val EXTRA_EN_VIAJE = "enViaje"
        const val EXTRA_RESUMEN_HOY = "resumenHoy"
        const val EXTRA_RESUMEN_SEMANA = "resumenSemana"
        const val EXTRA_RESUMEN_MES = "resumenMes"
        const val EXTRA_COLOR_ACENTO = "colorAcento"
        const val EXTRA_COLOR_FG = "colorFg"
        const val EXTRA_COLOR_SURFACE = "colorSurface"
        const val EXTRA_TARJETA_ACTIVA = "tarjetaActiva"
        const val EXTRA_ESTILO = "estilo"
        const val EXTRA_TOTAL_VIAJES = "totalViajes"
        const val EXTRA_SOLO_ESTILO = "soloEstilo"
        private const val CANAL_ID = "noah_burbuja"
        private const val NOTIF_ID = 4201
        private const val UMBRAL_TOQUE_MS = 650L
        private const val UMBRAL_ARRASTRE_PX = 12
        private const val UMBRAL_DESLIZAMIENTO_PX = 100
        private const val INTERVALO_RELOJ_MS = 1000L
        private const val PRECISION_MAXIMA_M = 35f
        private const val VELOCIDAD_MINIMA_MS = 0.42
        private const val VELOCIDAD_MAXIMA_MS = 55.0
        private const val INTERVALO_MAXIMO_S = 30.0
    }

    private lateinit var windowManager: WindowManager
    private lateinit var locationManager: LocationManager
    private var vistaBurbuja: View? = null
    private var vistaResumen: View? = null
    private var vistaManija: View? = null
    private lateinit var etiquetaTiempo: TextView
    private lateinit var etiquetaKm: TextView
    private lateinit var etiquetaViajes: TextView
    private lateinit var etiquetaResumen: TextView
    private var etiquetasPeriodo = emptyList<TextView>()
    private var periodoResumen = "hoy"
    private var resumenHoy = ""
    private var resumenSemana = ""
    private var resumenMes = ""
    private var colorAcento = "#D4AF37"
    private var colorFg = "#F3EDDD"
    private var colorSurface = "#14100A"
    private var tarjetaActiva = true
    private var estilo = "marea"
    private var enViaje = false
    private var inicioViajeMs = 0L
    private var kmAcumulados = 0.0
    private var viajesContados = 0
    private var ultimaUbicacion: Location? = null
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private val reloj = object : Runnable {
        override fun run() {
            if (enViaje) {
                actualizarTextos(formatearKm(kmAcumulados), formatearTiempo(System.currentTimeMillis() - inicioViajeMs))
                handler.postDelayed(this, INTERVALO_RELOJ_MS)
            }
        }
    }
    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            // La red puede saltar decenas o cientos de metros. Solo el proveedor
            // GPS se usa como fuente oficial de kilómetros.
            if (location.provider != LocationManager.GPS_PROVIDER) return
            if (location.accuracy <= 0f || location.accuracy > PRECISION_MAXIMA_M) {
                ultimaUbicacion = null
                return
            }
            val anterior = ultimaUbicacion
            if (anterior != null) {
                val distancia = anterior.distanceTo(location)
                val segundos = ((location.time - anterior.time).coerceAtLeast(1L)) / 1000.0
                val velocidad = distancia / segundos
                val umbralM = maxOf(8f, (location.accuracy + anterior.accuracy) * 0.5f)
                // Tras una pérdida de señal no se une el punto nuevo al anterior:
                // hacerlo convertiría un salto GPS en kilómetros recorridos.
                if (segundos > INTERVALO_MAXIMO_S) {
                    ultimaUbicacion = location
                    actualizarTextos(formatearKm(kmAcumulados), formatearTiempo(System.currentTimeMillis() - inicioViajeMs))
                    return
                }
                if (distancia >= umbralM && velocidad >= VELOCIDAD_MINIMA_MS && velocidad <= VELOCIDAD_MAXIMA_MS) {
                    kmAcumulados += distancia / 1000.0
                } else if (velocidad > VELOCIDAD_MAXIMA_MS) {
                    // Punto incompatible con la velocidad de una moto/carro: se
                    // descarta y se reinicia la referencia para no arrastrar el salto.
                    ultimaUbicacion = location
                    actualizarTextos(formatearKm(kmAcumulados), formatearTiempo(System.currentTimeMillis() - inicioViajeMs))
                    return
                }
            }
            ultimaUbicacion = location
            actualizarTextos(formatearKm(kmAcumulados), formatearTiempo(System.currentTimeMillis() - inicioViajeMs))
        }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        activo = true
        getSharedPreferences("noah-burbuja", MODE_PRIVATE).edit().putBoolean("servicio_activo", true).apply()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        tts = TextToSpeech(this, this)
    }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale("es", "CO") }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        crearCanalSiHaceFalta()
        startForeground(NOTIF_ID, construirNotificacion())
        resumenHoy = intent?.getStringExtra(EXTRA_RESUMEN_HOY) ?: resumenHoy
        resumenSemana = intent?.getStringExtra(EXTRA_RESUMEN_SEMANA) ?: resumenSemana
        resumenMes = intent?.getStringExtra(EXTRA_RESUMEN_MES) ?: resumenMes
        colorAcento = intent?.getStringExtra(EXTRA_COLOR_ACENTO) ?: colorAcento
        colorFg = intent?.getStringExtra(EXTRA_COLOR_FG) ?: colorFg
        colorSurface = intent?.getStringExtra(EXTRA_COLOR_SURFACE) ?: colorSurface
        getSharedPreferences("noah-burbuja", MODE_PRIVATE).edit().putString(EXTRA_COLOR_ACENTO, colorAcento).putString(EXTRA_COLOR_FG, colorFg).putString(EXTRA_COLOR_SURFACE, colorSurface).apply()
        tarjetaActiva = intent?.getBooleanExtra(EXTRA_TARJETA_ACTIVA, tarjetaActiva) ?: tarjetaActiva
        estilo = intent?.getStringExtra(EXTRA_ESTILO) ?: estilo
        val km = intent?.getStringExtra(EXTRA_KM) ?: formatearKm(kmAcumulados)
        val tiempo = intent?.getStringExtra(EXTRA_TIEMPO) ?: formatearTiempo(if (enViaje) System.currentTimeMillis() - inicioViajeMs else 0)
        val estadoSolicitado = intent?.getBooleanExtra(EXTRA_EN_VIAJE, enViaje) ?: enViaje
        val viajesExternos = intent?.getIntExtra(EXTRA_TOTAL_VIAJES, -1) ?: -1
        if (viajesExternos >= 0) viajesContados = viajesExternos
        if (estadoSolicitado && !enViaje) iniciarViaje(false)
        if (!estadoSolicitado && enViaje) finalizarViaje(false)
        if (vistaBurbuja == null) crearBurbuja()
        if (tarjetaActiva && vistaManija == null) crearManijaResumen()
        if (!tarjetaActiva && vistaManija != null) { vistaManija?.let { runCatching { windowManager.removeView(it) } }; vistaManija = null }
        aplicarColores()
        if (intent?.getBooleanExtra(EXTRA_SOLO_ESTILO, false) == true) return START_STICKY
        actualizarTextos(km, tiempo)
        return START_STICKY
    }

    override fun onDestroy() {
        activo = false
        detenerGps(); handler.removeCallbacksAndMessages(null); tts?.stop(); tts?.shutdown()
        getSharedPreferences("noah-burbuja", MODE_PRIVATE).edit().putBoolean("servicio_activo", false).apply()
        vistaResumen?.let { runCatching { windowManager.removeView(it) } }
        vistaManija?.let { runCatching { windowManager.removeView(it) } }
        vistaBurbuja?.let { runCatching { windowManager.removeView(it) } }
        vistaResumen = null; vistaManija = null; vistaBurbuja = null
        super.onDestroy()
    }

    private fun iniciarViaje(anunciar: Boolean) {
        if (enViaje) return
        enViaje = true; viajesContados += 1; inicioViajeMs = System.currentTimeMillis(); kmAcumulados = 0.0; ultimaUbicacion = null
        solicitarGps(); handler.removeCallbacks(reloj); handler.post(reloj)
        if (anunciar) hablar("Viaje iniciado")
        actualizarTextos("0.0", "0m")
    }

    private fun finalizarViaje(anunciar: Boolean) {
        if (!enViaje) return
        val finMs = System.currentTimeMillis(); val duracionMs = (finMs - inicioViajeMs).coerceAtLeast(0L); val kmFinal = kmAcumulados; val inicioMs = inicioViajeMs
        enViaje = false; detenerGps(); handler.removeCallbacks(reloj)
        if (anunciar) hablar("Viaje finalizado")
        actualizarTextos(formatearKm(kmFinal), formatearTiempo(duracionMs))
        getSharedPreferences("noah-burbuja", MODE_PRIVATE).edit()
            .putFloat("viaje_km", kmFinal.toFloat()).putLong("viaje_inicio", inicioMs)
            .putLong("viaje_fin", finMs).putLong("viaje_tiempo", duracionMs).apply()
        if (anunciar) BurbujaPlugin.instanciaActiva?.notificarAccion("terminar", kmFinal, inicioMs, finMs, duracionMs)
    }

    private fun solicitarGps() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        runCatching {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 5f, locationListener, Looper.getMainLooper())
        }
    }
    private fun detenerGps() { runCatching { locationManager.removeUpdates(locationListener) }; ultimaUbicacion = null }
    private fun hablar(texto: String) { tts?.speak(texto, TextToSpeech.QUEUE_FLUSH, null, "noah-viaje-${System.currentTimeMillis()}") }
    private fun crearCanalSiHaceFalta() { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { val nm = getSystemService(NotificationManager::class.java); if (nm.getNotificationChannel(CANAL_ID) == null) nm.createNotificationChannel(NotificationChannel(CANAL_ID, "Jornada activa", NotificationManager.IMPORTANCE_LOW)) } }
    private fun construirNotificacion(): android.app.Notification {
        val abrirApp = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CANAL_ID).setContentTitle("NOAH · jornada abierta").setContentText("La burbuja está contando el tiempo y los kilómetros.").setSmallIcon(R.mipmap.ic_launcher).setContentIntent(abrirApp).setOngoing(true).build()
    }

    private fun crearBurbuja() {
        val tamano = when (estilo) { "pulso" -> dp(78); "taller" -> dp(62); else -> dp(88) }; val contenedor = FrameLayout(this)
        contenedor.background = GradientDrawable().apply { shape = if (estilo == "pulso") GradientDrawable.OVAL else GradientDrawable.RECTANGLE; cornerRadius = if (estilo == "taller") dp(8).toFloat() else dp(28).toFloat(); setColor(colorSeguro(colorSurface, "#14100A")); setStroke(if (estilo == "pulso") dp(3) else dp(2), colorSeguro(colorAcento, "#D4AF37")) }
        etiquetaTiempo = TextView(this).apply { setTextColor(colorVisible(colorFg, colorSurface)); textSize = 12f; gravity = Gravity.CENTER }
        etiquetaKm = TextView(this).apply { setTextColor(colorSeguro(colorAcento, "#D4AF37")); textSize = 9f; gravity = Gravity.CENTER }
        etiquetaViajes = TextView(this).apply { setTextColor(colorVisible(colorFg, colorSurface)); textSize = if (estilo == "pulso") 9f else 8f; gravity = Gravity.CENTER }
        val columna = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; addView(etiquetaTiempo); addView(etiquetaKm); addView(etiquetaViajes) }
        contenedor.addView(columna, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        val tipoVentana = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(tamano, tamano, tipoVentana, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = dp(12); y = dp(160) }
        var xInicial = 0; var yInicial = 0; var toqueXInicial = 0f; var toqueYInicial = 0f; var tiempoInicioToque = 0L; var fueArrastre = false
        contenedor.setOnTouchListener { _, evento ->
            when (evento.action) {
                MotionEvent.ACTION_DOWN -> { xInicial = params.x; yInicial = params.y; toqueXInicial = evento.rawX; toqueYInicial = evento.rawY; tiempoInicioToque = System.currentTimeMillis(); fueArrastre = false; true }
                MotionEvent.ACTION_MOVE -> { val dx = (evento.rawX - toqueXInicial).toInt(); val dy = (evento.rawY - toqueYInicial).toInt(); if (abs(dx) > UMBRAL_ARRASTRE_PX || abs(dy) > UMBRAL_ARRASTRE_PX) fueArrastre = true; params.x = xInicial + dx; params.y = yInicial + dy; runCatching { windowManager.updateViewLayout(contenedor, params) }; true }
                MotionEvent.ACTION_UP -> {
                    val dx = evento.rawX - toqueXInicial; val duracion = System.currentTimeMillis() - tiempoInicioToque; val cercaDelFondo = params.y > resources.displayMetrics.heightPixels - dp(220)
                    when {
                        fueArrastre && dx < -UMBRAL_DESLIZAMIENTO_PX && tarjetaActiva -> mostrarResumen(params)
                        fueArrastre && dx > UMBRAL_DESLIZAMIENTO_PX -> ocultarResumen()
                        fueArrastre && cercaDelFondo -> { BurbujaPlugin.instanciaActiva?.notificarAccion("cerrar"); stopSelf() }
                        !fueArrastre && duracion >= UMBRAL_TOQUE_MS -> startActivity(Intent(this, MainActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT) })
                        !fueArrastre -> if (enViaje) finalizarViaje(true) else { iniciarViaje(true); BurbujaPlugin.instanciaActiva?.notificarAccion("iniciar") }
                    }; true
                }
                else -> false
            }
        }
        windowManager.addView(contenedor, params); vistaBurbuja = contenedor
        if (estilo == "pulso") ValueAnimator.ofFloat(0.62f, 1f).apply { duration = 700; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE; addUpdateListener { contenedor.alpha = it.animatedValue as Float }; start() }
    }

    private fun crearManijaResumen() {
        val manija = TextView(this).apply {
            text = when (estilo) { "pulso" -> "◉"; "taller" -> "▣"; else -> "≈" }
            textSize = if (estilo == "pulso") 15f else 18f
            gravity = Gravity.CENTER
            setTextColor(colorSeguro(colorFg, "#FFFFFF"))
            background = GradientDrawable().apply { shape = if (estilo == "pulso") GradientDrawable.OVAL else GradientDrawable.RECTANGLE; cornerRadius = dp(12).toFloat(); setColor(colorSeguro(colorSurface, "#14100A")); setStroke(dp(1), colorSeguro(colorAcento, "#D4AF37")) }
            setOnClickListener { if (vistaResumen == null) abrirResumenDesdeManija() else ocultarResumen() }
        }
        val params = WindowManager.LayoutParams(if (estilo == "pulso") dp(26) else if (estilo == "taller") dp(18) else dp(24), if (estilo == "pulso") dp(92) else dp(110), tipoVentana(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = dp(3); y = dp(260) }
        windowManager.addView(manija, params)
        vistaManija = manija
    }

    private fun abrirResumenDesdeManija() {
        val params = WindowManager.LayoutParams(dp(184), dp(174), tipoVentana(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = dp(14); y = dp(220) }
        mostrarResumen(params)
    }

    private fun mostrarResumen(burbujaParams: WindowManager.LayoutParams) {
        if (vistaResumen != null) return
        val contenedor = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)) }
        val pestañas = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val nombres = listOf("Hoy" to "hoy", "Semana" to "semana", "Mes" to "mes")
        etiquetasPeriodo = nombres.map { (nombre, clave) ->
            TextView(this).apply {
                text = nombre; textSize = 10f; gravity = Gravity.CENTER; setPadding(dp(7), dp(5), dp(7), dp(5))
                setOnClickListener { periodoResumen = clave; actualizarResumenSeleccionado() }
                pestañas.addView(this, LinearLayout.LayoutParams(0, dp(28), 1f))
            }
        }
        etiquetaResumen = TextView(this).apply { textSize = 12f; setPadding(dp(4), dp(8), dp(4), dp(2)); text = textoResumenSeleccionado() }
        contenedor.addView(pestañas); contenedor.addView(etiquetaResumen, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        val fondo = GradientDrawable().apply { shape = if (estilo == "pulso") GradientDrawable.OVAL else GradientDrawable.RECTANGLE; cornerRadius = if (estilo == "taller") dp(4).toFloat() else dp(22).toFloat(); setColor(colorSeguro(colorSurface, "#14100A")); setStroke(dp(if (estilo == "pulso") 2 else 1), colorSeguro(colorAcento, "#D4AF37")) }; contenedor.background = fondo
        val params = WindowManager.LayoutParams(dp(184), dp(174), tipoVentana(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = dp(14); y = dp(220) }
        windowManager.addView(contenedor, params); vistaResumen = contenedor; actualizarResumenSeleccionado()
    }
    private fun ocultarResumen() { vistaResumen?.let { runCatching { windowManager.removeView(it) } }; vistaResumen = null }
    private fun textoResumenSeleccionado(): String {
        val datos = when (periodoResumen) { "semana" -> resumenSemana; "mes" -> resumenMes; else -> resumenHoy }
        val partes = datos.split(" · ")
        val viajes = partes.getOrNull(0)?.replace(" viajes", "")?.replace(" viaje", "")?.ifBlank { "0" } ?: "0"
        val dinero = partes.getOrNull(1)?.ifBlank { "$0" } ?: "$0"
        val km = partes.getOrNull(2)?.replace(" km", "")?.ifBlank { "0.0" } ?: "0.0"
        return "viajes       $viajes\ntotal          $dinero\nkilómetros   $km km"
    }
    private fun actualizarResumenSeleccionado() { if (::etiquetaResumen.isInitialized) etiquetaResumen.text = textoResumenSeleccionado(); etiquetasPeriodo.forEachIndexed { i, vista -> vista.setTypeface(null, if (listOf("hoy", "semana", "mes")[i] == periodoResumen) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL) } }
    private fun aplicarColores() {
        if (::etiquetaTiempo.isInitialized) {
            etiquetaTiempo.setTextColor(colorVisible(colorFg, colorSurface)); etiquetaKm.setTextColor(colorSeguro(colorAcento, "#D4AF37")); etiquetaViajes.setTextColor(colorVisible(colorFg, colorSurface))
            (etiquetaTiempo.parent?.parent as? View)?.background = GradientDrawable().apply { shape = if (estilo == "pulso") GradientDrawable.OVAL else GradientDrawable.RECTANGLE; cornerRadius = if (estilo == "taller") dp(8).toFloat() else dp(28).toFloat(); setColor(colorSeguro(colorSurface, "#14100A")); setStroke(dp(if (estilo == "pulso") 3 else 2), colorSeguro(colorAcento, "#D4AF37")) }
        }
        if (::etiquetaResumen.isInitialized) { etiquetaResumen.setTextColor(colorVisible(colorFg, colorSurface)); etiquetasPeriodo.forEach { it.setTextColor(colorVisible(colorFg, colorSurface)) }; (vistaResumen?.background as? GradientDrawable)?.setColor(colorSeguro(colorSurface, "#14100A")); (vistaResumen?.background as? GradientDrawable)?.setStroke(dp(1), colorSeguro(colorAcento, "#D4AF37")) }
        if (vistaManija is TextView) { val manija = vistaManija as TextView; manija.setTextColor(colorVisible(colorFg, colorSurface)); (manija.background as? GradientDrawable)?.setColor(colorSeguro(colorSurface, "#14100A")); (manija.background as? GradientDrawable)?.setStroke(dp(1), colorSeguro(colorAcento, "#D4AF37")) }
    }
    private fun colorSeguro(valor: String, respaldo: String): Int = runCatching { Color.parseColor(valor.trim()) }.getOrElse { Color.parseColor(respaldo) }
    private fun colorVisible(texto: String, fondo: String): Int {
        val t = colorSeguro(texto, "#FFFFFF")
        val f = colorSeguro(fondo, "#14100A")
        val tl = (0.2126 * Color.red(t) + 0.7152 * Color.green(t) + 0.0722 * Color.blue(t)) / 255.0
        val fl = (0.2126 * Color.red(f) + 0.7152 * Color.green(f) + 0.0722 * Color.blue(f)) / 255.0
        return if (kotlin.math.abs(tl - fl) < 0.28) { if (fl > 0.55) Color.BLACK else Color.WHITE } else t
    }
    private fun tipoVentana() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
    private fun actualizarTextos(km: String, tiempo: String) { if (::etiquetaTiempo.isInitialized) { etiquetaTiempo.text = tiempo.ifBlank { "0m" }.replace(Regex("\\s+\\d{2}s"), ""); etiquetaKm.text = "${km.ifBlank { "0.0" }} km"; etiquetaViajes.text = "$viajesContados viaje${if (viajesContados == 1) "" else "s"}"; if (vistaResumen != null) actualizarResumenSeleccionado() } }
    private fun formatearTiempo(ms: Long): String { val totalMinutos = (ms / 60000).coerceAtLeast(0); val horas = totalMinutos / 60; val minutos = totalMinutos % 60; return if (horas > 0) "%dh %02dm".format(horas, minutos) else "${minutos}m" }
    private fun formatearKm(km: Double): String = "%.1f".format(Locale.US, km)
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
