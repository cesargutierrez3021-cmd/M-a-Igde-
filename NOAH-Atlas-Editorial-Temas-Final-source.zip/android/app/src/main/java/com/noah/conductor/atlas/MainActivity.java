package com.noah.conductor.atlas;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
import com.noah.conductor.atlas.alarma.AlarmaPantallaPlugin;
import com.noah.conductor.atlas.burbuja.BurbujaPlugin;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(BurbujaPlugin.class);
        registerPlugin(AlarmaPantallaPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
