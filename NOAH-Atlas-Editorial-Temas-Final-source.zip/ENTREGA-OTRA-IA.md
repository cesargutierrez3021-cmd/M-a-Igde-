# NOAH Conductor — paquete de continuidad

Este paquete contiene el proyecto fuente completo de la aplicación móvil NOAH Conductor. Está preparado para que otra persona o IA pueda continuar el desarrollo sin depender de la sesión original.

## Contenido

- `src/`: código fuente React/TypeScript.
- `android/`: proyecto Android/Capacitor, código Kotlin, manifiesto, recursos, voces y wrapper Gradle.
- `public/voices/`: copias web de las voces para preescucha.
- `package.json` y `package-lock.json`: dependencias JavaScript exactas.
- `capacitor.config.ts`: configuración de Capacitor.
- `README.md`: instrucciones generales del proyecto.
- `CAMBIOS-V37.md`: resumen funcional de la versión entregada.
- `NOAH-Conductor-v37-final-debug.apk`: APK de prueba generada desde este código.

## Requisitos

Node.js 22 o compatible, npm, Java 21 y Android SDK con plataforma/build-tools 36. El proyecto usa Capacitor y Gradle Wrapper, por lo que no es necesario instalar Gradle manualmente.

## Instalación y build web

```bash
npm ci
npm run lint
npm run build
```

## Sincronizar y compilar APK

```bash
npx cap sync android
cd android
./gradlew assembleDebug --no-daemon
```

La APK resultante aparece en `android/app/build/outputs/apk/debug/app-debug.apk`.

## Validación Android

```bash
cd android
./gradlew lintDebug --no-daemon
```

La versión entregada fue validada con Oxlint sin advertencias ni errores y Android lint con build correcto.

## Funciones añadidas en v37

La pantalla de últimos días permite quitar viajes individuales y eliminar todos los viajes y la jornada de un día de pruebas. El tema Editorial tiene una quinta variante azul oscura con los mismos gradientes y estructura de la variante vino. Las alarmas repiten la voz cada dos segundos hasta que se pulsa `DESCARTAR`; al descartar se detienen el reproductor, la vibración y los ciclos pendientes.

## Estado Git

El paquete corresponde al commit local:

```text
27d4db1 Add test record deletion editorial blue palette and looping alarms
```

El push remoto no pudo realizarse desde la sesión original porque no había credenciales GitHub habilitadas. Al abrir este paquete en un entorno autenticado, se puede ejecutar:

```bash
git remote -v
git push origin claude/hola-tpdd08
```

## APK incluida

La APK incluida es `1.0.37`, código 37. SHA-256:

```text
a428458b7252b2d3128468aed9655a8cd60dff45186afbb0fb174cdda7e4f73d
```
