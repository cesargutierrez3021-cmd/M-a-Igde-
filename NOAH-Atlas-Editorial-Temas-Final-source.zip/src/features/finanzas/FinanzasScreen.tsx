import { useState } from 'react'
import { Home, FileStack } from 'lucide-react'
import { Pantalla, TituloPantalla } from '../../components/shell/Pantalla'
import { HogarScreen } from '../hogar/HogarScreen'
import { DeudasScreen } from '../deudas/DeudasScreen'

type Pestaña = 'hogar' | 'deudas'

/** Un solo panel de navegación para las dos áreas, sin cambiar sus operaciones. */
export function FinanzasScreen() {
  const [pestaña, setPestaña] = useState<Pestaña>('hogar')

  return (
    <Pantalla>
      <TituloPantalla kicker="Casa y obligaciones" titulo="Hogar y deudas" bajada="Todo en un solo panel, separado en dos pestañas para mantener cada función clara." />
      <div className="mt-4 flex gap-2 rounded-[var(--radius-card)] border border-line bg-surface p-1.5">
        <button
          type="button"
          onClick={() => setPestaña('hogar')}
          className={`flex flex-1 items-center justify-center gap-2 rounded-[var(--radius-btn)] px-3 py-2.5 text-[12px] font-semibold uppercase ${pestaña === 'hogar' ? 'text-acento-alto' : 'text-mute'}`}
          style={pestaña === 'hogar' ? { background: 'var(--grad-acento-suave)' } : undefined}
        >
          <Home size={15} /> Hogar
        </button>
        <button
          type="button"
          onClick={() => setPestaña('deudas')}
          className={`flex flex-1 items-center justify-center gap-2 rounded-[var(--radius-btn)] px-3 py-2.5 text-[12px] font-semibold uppercase ${pestaña === 'deudas' ? 'text-acento-alto' : 'text-mute'}`}
          style={pestaña === 'deudas' ? { background: 'var(--grad-acento-suave)' } : undefined}
        >
          <FileStack size={15} /> Deudas
        </button>
      </div>
      <div className="mt-2">{pestaña === 'hogar' ? <HogarScreen /> : <DeudasScreen />}</div>
    </Pantalla>
  )
}
