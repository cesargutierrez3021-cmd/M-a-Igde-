import { HashRouter, Route, Routes, Link } from 'react-router-dom'
import { Settings2 } from 'lucide-react'
import { ProveedorApariencia } from './lib/theme'
import { useApariencia } from './lib/useApariencia'
import { EleccionApariencia } from './features/apariencia/EleccionApariencia'
import { NavInferior } from './components/shell/BottomNav'
import { FinanzasScreen } from './features/finanzas/FinanzasScreen'
import { BalanceScreen } from './features/balance/BalanceScreen'
import { AvisosScreen } from './features/avisos/AvisosScreen'
import { RutinaScreen } from './features/rutina/RutinaScreen'
import { AjustesScreen } from './features/ajustes/AjustesScreen'
import { AtlasScreen } from './features/atlas/AtlasScreen'
import { AtlasTipstersScreen } from './features/tipsters/AtlasTipstersScreen'
import { AtlasThemeProvider, AtlasModuleFrame } from './features/atlas/atlasTheme'
import { useEffect, useMemo } from 'react'
import { useTienda } from './lib/store'
import { proximosVencimientos } from './lib/selectors'
import { reprogramarVencimientos } from './features/avisos/programador'
import { LocalNotifications } from '@capacitor/local-notifications'
import './atlas.css'
import './atlas-modules.css'
import './atlas-special.css'
import './atlas-colors.css'
import './atlas-access.css'
import './atlas-onboarding.css'

function Interior() {
  const { yaEligio } = useApariencia()
  const generar = useTienda((s) => s.generarGastosFijosDelMes)
  const estado = useTienda()
  const vencimientos = useMemo(() => proximosVencimientos({ deudas: estado.deudas, gastosHogarFijos: estado.gastosHogarFijos, gastosHogar: estado.gastosHogar }), [estado.deudas, estado.gastosHogarFijos, estado.gastosHogar])

  useEffect(() => {
    generar()
  }, [generar])

  useEffect(() => {
    void (async () => {
      if (!((window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor?.isNativePlatform?.())) return
      await LocalNotifications.requestPermissions().catch(() => {})
      await reprogramarVencimientos(vencimientos)
    })()
  }, [vencimientos])

  if (!yaEligio) return <EleccionApariencia />

  return (
    <HashRouter>
      <div className="min-h-dvh">
        <Link to="/ajustes" className="atlas-settings-access" aria-label="Abrir ajustes"><Settings2 size={18} /><span>Ajustes</span></Link>
        <Routes>
          <Route path="/" element={<AtlasScreen />} />
          <Route path="/finanzas" element={<AtlasModuleFrame module="Casa y deudas"><FinanzasScreen /></AtlasModuleFrame>} />
          <Route path="/balance" element={<AtlasModuleFrame module="Balance"><BalanceScreen /></AtlasModuleFrame>} />
          <Route path="/avisos" element={<AtlasModuleFrame module="Señales"><AvisosScreen /></AtlasModuleFrame>} />
          <Route path="/rutina" element={<AtlasModuleFrame module="Ritual"><RutinaScreen /></AtlasModuleFrame>} />
          <Route path="/ajustes" element={<AtlasModuleFrame module="Sistema"><AjustesScreen /></AtlasModuleFrame>} />
          <Route path="/tipsters" element={<AtlasModuleFrame module="Laboratorio"><AtlasTipstersScreen /></AtlasModuleFrame>} />
        </Routes>
        <NavInferior />
      </div>
    </HashRouter>
  )
}

export default function App() {
  return (
    <ProveedorApariencia>
      <AtlasThemeProvider><Interior /></AtlasThemeProvider>
    </ProveedorApariencia>
  )
}
