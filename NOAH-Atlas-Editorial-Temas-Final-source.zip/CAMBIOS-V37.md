# NOAH Conductor v1.0.37

## Cambios implementados

Se agregó eliminación de viajes individuales desde el historial desplegable de “Últimos días” y una acción “Eliminar día de pruebas” que elimina los viajes y la jornada correspondientes a la fecha seleccionada. También se limpian las referencias `viajesIds` de las jornadas.

Se agregó la quinta variante de apariencia para el tema Editorial: `quinto`. Conserva la estructura editorial oscura, bordes dobles, tipografía, sombras y gradientes, pero reemplaza la tonalidad vino/rojiza por una paleta azul oscura y difuminada. Está disponible tanto en la selección inicial como en Ajustes.

La alarma de voz ahora repite la voz automáticamente: al terminar una reproducción espera dos segundos y vuelve a reproducirla hasta que el usuario pulse “DESCARTAR”. Al descartar se cancelan los ciclos pendientes, se detiene el reproductor y se cancela la vibración.

## Verificación

Oxlint: `Found 0 warnings and 0 errors`.

Android lint: `BUILD SUCCESSFUL`.

Build web y APK: correctos.

APK: [NOAH-Conductor-v37-final-debug.apk](/home/ubuntu/NOAH-Conductor-v37-final-debug.apk)

Versión: `1.0.37`, código `37`.

SHA-256: `a428458b7252b2d3128468aed9655a8cd60dff45186afbb0fb174cdda7e4f73d`.

## Repositorio

Los cambios quedaron guardados en un commit local reproducible:

`27d4db1 Add test record deletion editorial blue palette and looping alarms`

El push a GitHub no pudo completarse porque esta sesión no tiene credenciales GitHub habilitadas. El repositorio remoto todavía está en el commit anterior `2e28cf1`. Para subirlo desde un entorno con acceso, ejecutar:

```bash
git push origin claude/hola-tpdd08
```
